package com.example.demo.service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long id) {
        User user = userRepository.findByIdWithLearningCourses(id);
        return user != null ? user : null;
    }

    public User createUser(User user) {
        try {
            // Hash the password before saving
            user.setPassword(passwordEncoder.encode(user.getPassword()));

            // Log the user data before saving
            logger.info("Attempting to save user: {}", user.getEmail());

            // Save the user
            User savedUser = userRepository.save(user);

            // Verify the user was saved by checking if it has an ID
            if (savedUser != null && savedUser.getId() != null) {
                logger.info("User saved successfully with ID: {}", savedUser.getId());
                return savedUser;
            } else {
                logger.error("User save operation failed - no ID returned");
                throw new RuntimeException("Failed to save user - no ID returned");
            }
        } catch (Exception e) {
            logger.error("Error saving user: {}", user.getEmail(), e);
            throw new RuntimeException("Failed to save user to database", e);
        }
    }

    public User updateUser(Long id, User updatedUser) {
        if (userRepository.existsById(id)) {
            updatedUser.setId(id);
            return userRepository.save(updatedUser);
        }
        return null;
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User authenticateUser(String email, String password) {
        User user = userRepository.findByEmail(email);

        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }

        return null;
    }


}
